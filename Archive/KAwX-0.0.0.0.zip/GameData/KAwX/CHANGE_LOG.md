# KAwX :: Change Log

* 2019-0515: 0.0.0.0 (Lisias) for KSP >= 1.4 PRE RELEASE
	+ Initial version with some essays about militarizing some KAX parts
	+ Alpha Release
